#Script by Enny Jole '18
#Cleans up scripts that won't be used again
cd /home/pi/dd_script/;
rm add_cron.sh autolaunch.sh autoterm.sh email_setup.sh ipid.sh timezone.sh update_and_upgrade.sh;
