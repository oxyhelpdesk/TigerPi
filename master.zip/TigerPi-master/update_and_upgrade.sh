#Script by Enny Jole '18
#This script automatically updates the repositories and upgrades the Pi
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin #environment
sudo apt-get update -y;
sudo apt-get upgrade -y;
